package com.example.yes;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.text.TextUtils;



import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;


public class Login extends AppCompatActivity {
    Button thirdButton;
    EditText email;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseAuth auth = FirebaseAuth.getInstance();

        if (auth.getCurrentUser() != null) {
            startActivity(new Intent(Login.this, Apply.class));
            finish();
        }

        setContentView(R.layout.activity_login);
        email= findViewById(R.id.editText_designation);
        password=findViewById(R.id.editText10);


        //auth = FirebaseAuth.getInstance();



        thirdButton=findViewById(R.id.lb1);

        thirdButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {


                String email2 = email.getText().toString().trim();
                final String password2 = password.getText().toString().trim();


                if (TextUtils.isEmpty(email2)) {
                    Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(password2)) {
                    Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                    return;
                }


                else
                {
                   Toast.makeText(Login.this, "Fill all the credentials",Toast.LENGTH_SHORT).show();

                }
                if(!email.getText().toString().isEmpty() && !password.getText().toString().isEmpty()){

                    Toast.makeText(Login.this, R.string.Success_label,Toast.LENGTH_SHORT).show();
                    Intent intent_one = new Intent(Login.this,Apply.class);
                    startActivity(intent_one);
                }

            }


        }
        );
    }
}
