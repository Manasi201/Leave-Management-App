package com.example.yes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class Register extends AppCompatActivity {

    EditText name;
    EditText phone_no;
    EditText email;
    EditText qualification;
    EditText designation;
    EditText branch;
    EditText experience;
    EditText password;
    Button R_button;
    private FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        auth=FirebaseAuth.getInstance();
        name=(EditText)findViewById(R.id.editText_name);
        phone_no=(EditText)findViewById(R.id.editText_designation);
        email=(EditText)findViewById(R.id.editText3);
        qualification=(EditText)findViewById(R.id.editTextReason);
        designation=(EditText)findViewById(R.id.editText9);
        branch=(EditText)findViewById(R.id.editText_leaveAvailable);
        experience=(EditText)findViewById(R.id.editText_POL);
        password=(EditText)findViewById(R.id.editText7);



        R_button=findViewById(R.id.tb1);
        R_button.setOnClickListener(new View.OnClickListener()
                                    {
                                        @Override
                                        public void onClick(View view) {
                                            String email2 =email.getText().toString().trim();
                                            final String password2=password.getText().toString().trim();

                                            if(!name.getText().toString().isEmpty() && !phone_no.getText().toString().isEmpty()&& !email.getText().toString().isEmpty()&& !qualification.getText().toString().isEmpty()&& !designation.getText().toString().isEmpty()&& !branch.getText().toString().isEmpty()&& !experience.getText().toString().isEmpty()&& !password.getText().toString().isEmpty())

                                            {
                                                auth.createUserWithEmailAndPassword(email2,password2).addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                                        Toast.makeText(Register.this,"Registration done successfully:",Toast.LENGTH_SHORT).show();
                                                        if(!task.isSuccessful())
                                                        {
                                                            //Toast.makeText(Register.this,"",Toast.LENGTH_SHORT).show();

                                                        }else {
                                                            startActivity(new Intent (Register.this,Login.class));

                                                        }

                                                    }
                                                });
                                            }
                                            else
                                            {
                                                Toast.makeText(Register.this, "Fill all the credentials",Toast.LENGTH_SHORT).show();

                                            }

                                        }

                                        //CREATE USER

                                    }
        );
    }
}





