package com.example.yes;

public class FRegistration {
    private String id,name,designation,pol,reason,alternateArr,leaveAvailable;
    FRegistration(){

    }

    public FRegistration(String id,String name, String designation, String pol, String reason, String alternateArr, String leaveAvailable) {
        this.name =name;
        this.id=id;
        this.designation = designation;
        this.pol = pol;
        this.reason = reason;
        this.alternateArr = alternateArr;
        this.leaveAvailable = leaveAvailable;
    }


    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDesignation() {
        return designation;
    }

    public String getPol() {
        return pol;
    }

    public String getReason() {
        return reason;
    }

    public String getAlternateArr() {
        return alternateArr;
    }

    public String getLeaveAvailable() {
        return leaveAvailable;
    }
}
