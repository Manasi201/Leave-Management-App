package com.example.yes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Apply extends AppCompatActivity {

    EditText name;
    EditText designation;
    EditText period;
    EditText reason;
    EditText leave;
    Button a_button;
    Spinner spinner;
    DatabaseReference databaseRegistration;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply);
        databaseRegistration = FirebaseDatabase.getInstance().getReference("Leaves");
        name=(EditText)findViewById(R.id.editText_name);
        designation=(EditText)findViewById(R.id.editText_designation);
        period=(EditText)findViewById(R.id.editText_POL);
        reason=(EditText)findViewById(R.id.editTextReason);
        leave=(EditText)findViewById(R.id.editText_leaveAvailable);
        spinner=(Spinner)findViewById(R.id.spinner);
        a_button=(Button) findViewById(R.id.button_submit_applyActivity);
        a_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!name.getText().toString().isEmpty() && !designation.getText().toString().isEmpty()&& !period.getText().toString().isEmpty()&& !reason.getText().toString().isEmpty()&& !leave.getText().toString().isEmpty())
                {   addLeave();
                    Toast.makeText(Apply.this,"Applied Successfully",Toast.LENGTH_SHORT).show();

                }
                else
                    {
                        Toast.makeText(Apply.this,"Fill all the credentials",Toast.LENGTH_SHORT).show();

                    }

            }


        }
        );
    }
    private void addLeave(){
        String name2 =name.getText().toString().trim();
        String designation2 = designation.getText().toString().trim();
        String spinner2 = spinner.getSelectedItem().toString().trim();
        String period2 = period.getText().toString().trim();
        String reason2 = reason.getText().toString().trim();
        String leave2 = leave.getText().toString().trim();
        String id2= databaseRegistration.push().getKey();
       // public FRegistration(String id,String name, String designation, String pol, String reason, String alternateArr, String leaveAvailable)
        FRegistration registration =new FRegistration(id2,name2,designation2,period2,reason2,spinner2,leave2);
        databaseRegistration.child(id2).setValue(registration);


    }
}


